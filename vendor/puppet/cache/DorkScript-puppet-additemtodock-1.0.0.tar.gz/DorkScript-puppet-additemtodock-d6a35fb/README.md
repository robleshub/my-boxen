#  additemtodock Puppet Module for Boxen

## Usage

```puppet
include additemtodock
```

## Required Puppet Modules

None.
